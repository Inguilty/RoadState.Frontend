import React from "react";

const AboutPage = props => <h2>About page</h2>;

export default AboutPage;
