import React from 'react';

const HomePage = props => <h2>Home page</h2>;

export default HomePage;
